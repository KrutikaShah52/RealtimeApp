import { Component } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  books;
  saved;
  
   product: any = {};
 
  constructor(public http: HttpClient) {
  //console.log('constructor-----------------');
    http.get('http://localhost:3000/people.json')
      .subscribe(res => this.books = res);

  }

  onSubmit(){
  	console.log('on submit:'+this.product.name);
  	let product_name = this.product.name;
  	let param = {name:product_name};
      // this.http.put('http://localhost:3000/people/2', param)
      // .subscribe(res => this.saved = res);
      this.http.post('http://localhost:3000/people', param)
      .subscribe(res => this.saved = res);
      location.reload();
  }
}
